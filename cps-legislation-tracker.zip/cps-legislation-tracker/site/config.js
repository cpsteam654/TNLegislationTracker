// Tracker settings. Fill these in during setup (see README.md).
// The publishable key is safe to show in a web page. Never put the secret key here.
window.CPS_CONFIG = {
  supabaseUrl: 'https://YOUR-PROJECT.supabase.co',
  supabaseKey: 'YOUR-PUBLISHABLE-KEY',
  // 'code' emails a 6-digit sign-in code; 'password' uses a password for each person
  signIn: 'code',
  // who teammates should ask when they can't get in
  adminContact: 'Kathryn Farris',
};
