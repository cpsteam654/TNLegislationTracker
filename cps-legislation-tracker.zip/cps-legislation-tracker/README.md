# CPS Legislation Tracker

The Cooley Public Strategies tracker for the 115th Tennessee General Assembly (2027 session), published as its own website.

**How it works**

- **The site** is hosted free on GitHub Pages at one permanent link the team can bookmark. No Claude account is needed to use it.
- **Bill updates** run on their own at 9am, noon and 5pm Central. A GitHub Action pulls new and changed bills from LegiScan, saves them here, and republishes the site. Nobody downloads or uploads anything.
- **Team records** (client folders, bill tags and notes, hearings, CPS connections and the outreach log) live in a free Supabase database. Everyone sees the same records, and each one is stamped "Added by K. Farris" with the date.
- **Signing in:** the opening page asks "Who's using the tracker?" You pick your name, and a 6-digit code goes to your work email. You stay signed in on that device after that.
- **Alerts:** when an update finds something important, like a new bill on a priority issue or a hearing for a tagged bill, an email goes out.

**What's in this folder**

| Path | What it is |
| --- | --- |
| `site/` | The website itself. `site/config.js` holds the database address. |
| `site/data/` | Bill and lawmaker files. The scheduled update rewrites these, so don't edit them by hand. |
| `scripts/update.mjs` | The scheduled bill update. |
| `.github/workflows/publish.yml` | The schedule and publishing steps. |
| `supabase/setup.sql` | Sets up the team database. Run it once. |
| `cache/` | The update's memory of what it has already seen. |

---

## One-time setup (about 30 minutes)

You'll need:

- your LegiScan API key
- the team's names and work emails
- access to the CPS Gmail account (cooleyps@gmail.com), which sends the sign-in codes and alerts

### Part 1: The database (Supabase)

1. Go to [supabase.com](https://supabase.com), sign up, and choose **New project**.
   - Name it `cps-legislation-tracker`.
   - Set a database password and save it somewhere safe.
   - Pick a US region.
   - Wait about two minutes for it to finish.
2. Open **SQL Editor**, then **New query**. Paste in everything from `supabase/setup.sql`, then click **Run**. You should see "Success."
3. **Add the team.** In a new query, paste the block below and fill in each person. The short name is what shows in "Added by." The `sort` number sets the order in the dropdown. Then click **Run**.

   ```sql
   insert into public.team_members (id, full_name, short_name, email, sort) values
     ('kfarris', 'Kathryn Farris', 'K. Farris', 'WORK-EMAIL-HERE', 1),
     ('dcooley', 'Dave Cooley',    'D. Cooley', 'WORK-EMAIL-HERE', 2)
   on conflict (id) do update set full_name = excluded.full_name, short_name = excluded.short_name,
     email = excluded.email, sort = excluded.sort, active = true;
   ```

   Later you can add or remove people under **Table Editor**, `team_members`. To remove someone's access, set `active` to false.
4. **Let it send sign-in codes.** Supabase's built-in email only reaches people on your Supabase account, so connect the CPS Gmail.
   1. In the Google account for cooleyps@gmail.com, turn on 2-Step Verification. Then create an **App password** at myaccount.google.com/apppasswords. Name it "Legislation Tracker" and copy the 16-letter password.
   2. In Supabase, go to **Authentication**, **Emails**, **SMTP Settings**, and turn on **Custom SMTP**. Enter:
      - Sender email: `cooleyps@gmail.com`
      - Sender name: `CPS Legislation Tracker`
      - Host: `smtp.gmail.com`
      - Port: `465`
      - Username: `cooleyps@gmail.com`
      - Password: the app password

      Then click **Save**.
   3. Still under **Authentication**, **Emails**, open the **Templates** tab. Change both **Confirm sign up** and **Magic link** so they send a code instead of a link:
      - Subject: `Your Legislation Tracker sign-in code`
      - Body:

        ```html
        <h2>Your sign-in code</h2>
        <p>Enter this code on the CPS Legislation Tracker to finish signing in:</p>
        <p style="font-size:28px;font-weight:700;letter-spacing:4px">{{ .Token }}</p>
        <p>It works for one hour. If you didn't ask for it, you can ignore this email.</p>
        ```
5. **Copy two keys.** Go to **Project Settings**, **API Keys**.
   - Copy the **Project URL** and the **Publishable key**. These go in the website and are safe to show.
   - Copy the **Secret key**. It goes only into GitHub's locked secrets in Part 2. Never put it in a file.

### Part 2: The website and automatic updates (GitHub)

1. Open `site/config.js` in any text editor. Replace `https://YOUR-PROJECT.supabase.co` and `YOUR-PUBLISHABLE-KEY` with the Project URL and Publishable key from step 5, then save.
2. In GitHub, create a **new repository** named `legislation-tracker`.
   - Make it **Public**. GitHub's free plan only publishes Pages from public repositories. No keys or team records live in these files.
   - Leave "Add a README" unchecked.
3. On the new repository's page, click **uploading an existing file**. Drag in everything inside this folder, including the `.github` folder, then click **Commit changes**.
   - On a Mac, `.github` is hidden. Press Cmd+Shift+Period in Finder to show it.
   - If `.github` doesn't come through, choose **Add file**, **Create new file**. Name it `.github/workflows/publish.yml`, paste in that file's contents, and commit.
4. Go to **Settings**, **Pages**. Under **Build and deployment**, set **Source** to **GitHub Actions**.
5. Go to **Settings**, **Secrets and variables**, **Actions**. Under **New repository secret**, add each of these:

   | Name | Value |
   | --- | --- |
   | `LEGISCAN_API_KEY` | your LegiScan key |
   | `SUPABASE_URL` | the Project URL |
   | `SUPABASE_SECRET_KEY` | the Supabase Secret key |
   | `MAIL_USERNAME` | `cooleyps@gmail.com` |
   | `MAIL_PASSWORD` | the Gmail app password from Part 1 |
   | `ALERT_EMAIL_TO` | who gets alerts, separated by commas |

6. Open the **Actions** tab. If GitHub asks, turn workflows on. Click **Update bills and publish**, then **Run workflow**. It takes about a minute. When the run turns green, the link appears next to **github-pages** on the repository's main page. It looks like `https://YOUR-ACCOUNT.github.io/legislation-tracker/`.
7. Back in Supabase, go to **Authentication**, **URL Configuration**, set **Site URL** to that link, and save.

### Part 3: Share it

Send the team the link and ask them to bookmark it. The first time, each person picks their name, gets a code by email, and is in.

---

## Day to day

- **New bills** appear on their own after the 9am, noon and 5pm runs. The sidebar shows when the bill data last updated.
- **Adding a teammate:** add a row to `team_members` in Supabase. They'll appear in the dropdown right away.
- **Changing the design:** replace the files in `site/css` or `site/js` and commit. The site republishes in about a minute, and bill data and team records aren't touched.
- **If an update fails** (a red X on the Actions tab), the site keeps showing the last good data. GitHub emails the repository owner. The most common cause is a LegiScan key that changed or ran out of monthly queries.
- **Custom address** (optional): to use something like `tracker.cooleypublicstrategies.com`, add it under **Settings**, **Pages**, **Custom domain**, and follow GitHub's DNS steps. Then add a repository **variable** (not a secret) named `SITE_URL` with the new address, so alert emails link to it.
- **Passwords instead of codes:** if you'd rather skip email codes, set `signIn: 'password'` in `site/config.js`. Then create each person in Supabase under **Authentication**, **Users**, **Add user**, with their email and a password, and check **Auto Confirm User**.

## Notes on privacy

- Bill and lawmaker information in `site/data` is public record and sits in the public repository.
- Client tags, notes, hearings, connections and outreach live only in Supabase. They can only be read by someone signed in whose email is on `team_members`.
- The opening page shows the names on the team list, and it looks up the work email each name signs in with.
- The site asks search engines not to list it.

Bill data from [LegiScan](https://legiscan.com), CC BY 4.0.
